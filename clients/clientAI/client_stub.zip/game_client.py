# Seção de Importações
import pygame
from wall import Wall
from player import Player
import client_stub
import json
from simulated_annealing import SimulatedAnnealing

"""
A grelha agora é construída com base no número de quadrados em x e y.
Isso nos permite associar o tamanho do espaço a uma matriz ou a um dicionário
que manterá os dados sobre cada posição no ambiente.
Além disso, agora podemos controlar o movimento dos objetos.
Agora separamos o controlo do ambiente
"""


class GameUI(object):
    def __init__(self, stub: client_stub.StubClient, player_id, player_name, grid_size: int = 20):
        dim: tuple = stub.dimension_size()
        self.x_max = dim[0]
        self.y_max = dim[1]
        self.stub = stub
        self.width, self.height = self.x_max * grid_size, self.y_max * grid_size
        self.screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption("Labyrinth Runners 2 - Player: " + player_name)
        self.clock = pygame.time.Clock()
        self.white = (255, 255, 255)
        self.black = (0, 0, 0)
        self.grid_size = grid_size
        self.background = pygame.Surface(self.screen.get_size())
        self.background = self.background.convert()
        self.background.fill(self.white)
        self.screen.blit(self.background, (0, 0))

        self.player_id = player_id
        self.player_name = player_name
        self.players = pygame.sprite.LayeredDirty()
        self.players_dict = {}
        self.visited_y_coords = set()

        self.draw_grid(self.black)
        self.last_player_y = 0
        self.last_player_x = 0

        self.maze = self.load_maze_config()
        self.portal_location = self.find_portal_location()
        self.sa_algorithm = None

    def load_maze_config(self):
        maze = []
        with open('maze.json', 'r') as file:
            for line in file:
                maze.append(list(line.strip()))
        return maze

    def find_portal_location(self):
        for y, row in enumerate(self.maze):
            for x, cell in enumerate(row):
                if cell == 'P':
                    return x, y
        return None

    def draw_grid(self, colour: tuple):
        current_player_y = None
        if self.player_id in self.players_dict:
            current_player_y = self.players_dict[self.player_id].rect.y // self.grid_size

        for x in range(0, self.x_max):
            for y in range(0, self.y_max):
                # Always draw the exterior walls
                if x == 0 or y == 0 or x == self.x_max - 1 or y == self.y_max - 1:
                    pygame.draw.line(self.screen, colour, (x * self.grid_size, y * self.grid_size),
                                     ((x + 1) * self.grid_size, y * self.grid_size))
                    pygame.draw.line(self.screen, colour, (x * self.grid_size, y * self.grid_size),
                                     (x * self.grid_size, (y + 1) * self.grid_size))
                elif current_player_y is not None and (y in self.visited_y_coords or
                                                       y == current_player_y or
                                                       y == current_player_y - 1 or
                                                       y == current_player_y + 1):
                    # Draw grid lines for visited, current, and adjacent Y-coordinates
                    pygame.draw.line(self.screen, colour, (x * self.grid_size, y * self.grid_size),
                                     ((x + 1) * self.grid_size, y * self.grid_size))
                    pygame.draw.line(self.screen, colour, (x * self.grid_size, y * self.grid_size),
                                     (x * self.grid_size, (y + 1) * self.grid_size))
                else:
                    # Draw darkness for unvisited cells
                    dark_surface = pygame.Surface((self.grid_size, self.grid_size))
                    dark_surface.set_alpha(255)  # Adjust alpha for darkness intensity
                    dark_surface.fill((0, 0, 0))  # Black color
                    self.screen.blit(dark_surface, (x * self.grid_size, y * self.grid_size))

    def set_players(self):
        """
        Coloca os jogadores no ecrã
        :return: None
        """
        self.pl = self.stub.get_players()
        nr_players = self.stub.get_nr_players()

        existing_players = list(self.pl.keys())  # Get the existing player numbers

        for nr in range(nr_players):
            if nr in existing_players:
                p_x, p_y = self.pl[nr][1][0], self.pl[nr][1][1]
                if nr not in self.players_dict:  # This player is new
                    player = Player(nr, self.pl[nr][0], p_x, p_y, self.grid_size)
                    self.players_dict[nr] = player  # Store the player object in self.players_dict
                else:
                    player = self.players_dict[nr]  # This player already exists
                    # Here, you can update player's attributes if needed
                self.players.add(player)
            else:
                # Player disconnected, remove from self.pl and self.players_dict
                self.pl.pop(nr, None)
                if nr in self.players_dict:
                    self.players_dict.pop(nr)

        print(f"Players: {self.pl}")

    def set_walls(self, wall_size: int):
        """
        Desenha as paredes no ecrã
        :param wall_size: Tamanho das paredes
        :return: None
        """
        self.wl = self.stub.get_obstacles()
        # Cria as paredes (sprites) ao redor do mundo
        self.walls = pygame.sprite.Group()
        nr_obstacles = self.stub.get_nr_obstacles()
        for nr in range(nr_obstacles):
            if self.wl[nr]:
                w_x, w_y = self.wl[nr][1][0], self.wl[nr][1][1]
                wall = Wall(w_x, w_y, self.grid_size, self.walls)
                self.walls.add(wall)

    def draw_finish(self, image_path):
        """Desenha a imagem final(portal)"""
        x, y = self.finish_cell
        finish_image = pygame.image.load(image_path)
        finish_image = pygame.transform.scale(finish_image, (self.grid_size, self.grid_size))
        self.screen.blit(finish_image, (x * self.grid_size, y * self.grid_size))

    def can_see_portal(self):
        visibility_range = 5  # Define how many squares the AI can see in each direction

        # Get current position of the AI player
        current_x, current_y = self.players_dict[self.player_id].rect.x // self.grid_size, \
                               self.players_dict[self.player_id].rect.y // self.grid_size

        # Calculate visibility bounds
        x_min, x_max = max(0, current_x - visibility_range), min(self.x_max, current_x + visibility_range)
        y_min, y_max = max(0, current_y - visibility_range), min(self.y_max, current_y + visibility_range)

        # Check if the portal is within the visibility bounds
        portal_x, portal_y = self.portal_location
        return x_min <= portal_x <= x_max and y_min <= portal_y <= y_max

    def follow_path(self, path):
        if not path:
            return  # No path to follow

        # Current position of the AI player
        current_pos = (self.players_dict[self.player_id].rect.x // self.grid_size,
                       self.players_dict[self.player_id].rect.y // self.grid_size)

        # Check if the next step in the path is adjacent to the current position
        # (In a real implementation, you might need more sophisticated checking)
        next_step = path[0]  # Assuming path is a list of tuples (x, y)
        if self.is_adjacent(current_pos, next_step):
            self.players_dict[self.player_id].moveto(*next_step)
            path.pop(0)  # Remove the step that's just been taken

    def is_adjacent(self, pos1, pos2):
        """Check if two positions are adjacent on the grid."""
        x1, y1 = pos1
        x2, y2 = pos2
        return abs(x1 - x2) + abs(y1 - y2) == 1

    def run(self):
        """
        Inicializa o jogo
        :return: Verdadeiro se o jogo terminou com sucesso, falso caso contrário.
        """

        window = pygame.display.get_surface()
        window_size = window.get_size()
        width, height = window_size

        self.set_walls(self.grid_size)
        self.walls.draw(self.screen)
        self.set_players()
        end = False
        nr_players = self.stub.get_nr_players()

        # O mundo é atualizado constantemente
        world = dict()

        self.finish_cell = self.stub.get_finish()

        while not end:

            game_over, winner = self.stub.get_game_status()

            # Update visited Y-coordinates
            for player in self.players_dict.values():
                player_y = player.rect.y // self.grid_size
                self.visited_y_coords.update({player_y, player_y - 1, player_y + 1})

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    # Enviar informação "desconectado"
                    # Se a resposta for ok, então end é verdadeiro
                    end = True
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    # Enviar informação "desconectado"
                    # Se a resposta for ok, então end é verdadeiro
                    end = True

            if self.portal_location and self.can_see_portal():
                if not self.sa_algorithm:
                    self.sa_algorithm = SimulatedAnnealing(self.maze, (current_x, current_y), self.portal_location)
                path = self.sa_algorithm.find_path()
                self.follow_path(path)

            # Get the current coordinates of the player
            current_x = self.players_dict[self.player_id].rect.x // self.grid_size
            current_y = self.players_dict[self.player_id].rect.y // self.grid_size

            # Request maze data from the server if the player moves within the known areas
            if (current_x, current_y) != (self.last_player_x, self.last_player_y):
                self.stub.request_maze()
                self.last_player_x = current_x
                self.last_player_y = current_y

            new_nr_players = self.stub.get_nr_players()
            if new_nr_players > nr_players:
                for nr in range(nr_players, new_nr_players):
                    if nr in self.pl and self.pl[nr] != []:
                        p_x, p_y = self.pl[nr][1][0], self.pl[nr][1][1]
                        player = Player(nr, self.pl[nr][0], p_x, p_y, self.grid_size, self.players)
                        self.players.add(player)
                nr_players = new_nr_players

            if not game_over:
                self.walls.draw(self.screen)
                if self.finish_cell is not None:
                    self.draw_finish(r"pictures/portal.png")
                self.players.update(self.stub)
                self.players.draw(self.screen)
                self.draw_grid(self.black)
                pygame.display.flip()
                self.players.clear(self.screen, self.background)
                self.screen.fill((200, 200, 200))

            else:
                if self.player_id == self.stub.get_game_status()[1]:
                    message = f"{self.player_name}, congratulations you won!"
                else:
                    message = "You lost!"
                font = pygame.font.Font(None, 36)
                self.screen.fill((56, 5, 7))
                text = font.render(message, True, (255, 255, 255))
                text_rect = text.get_rect(center=(width // 2, height // 2))
                self.screen.blit(text, text_rect)
                pygame.display.flip()
        return True

