import random
import math


class SimulatedAnnealing:
    def __init__(self, maze, start, goal):
        self.maze = maze
        self.start = start
        self.goal = goal
        self.predecessor = {start: None}

    def find_path(self):
        initial_temperature = 10
        cooling_rate = 0.01
        temperature = initial_temperature
        current_state = self.start

        while temperature > 0:
            next_state = self._get_neighbor(current_state)

            if next_state not in self.predecessor:
                self.predecessor[next_state] = current_state

            if self._is_better(next_state, current_state) or random.uniform(0, 1) < self._acceptance_probability(current_state, next_state, temperature):
                current_state = next_state

            if current_state == self.goal:
                break

            temperature -= cooling_rate

        return self._reconstruct_path(self.goal) if current_state == self.goal else []

    def _get_neighbor(self, state):
        x, y = state
        neighbors = [(x + dx, y + dy) for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]
                     if 0 <= x + dx < len(self.maze[0]) and 0 <= y + dy < len(self.maze)
                     and self.maze[y + dy][x + dx] != 1]
        return random.choice(neighbors) if neighbors else state

    def _is_better(self, state1, state2):
        return self._distance(state2, self.goal) < self._distance(state1, self.goal)

    def _acceptance_probability(self, current_state, next_state, temperature):
        if self._is_better(next_state, current_state):
            return 1
        else:
            return math.exp(-abs(self._distance(next_state, self.goal) - self._distance(current_state, self.goal)) / temperature)

    def _reconstruct_path(self, state):
        path = []
        while state != self.start:
            path.append(state)
            state = self.predecessor[state]
        path.append(self.start)
        path.reverse()
        return path

    def _distance(self, state1, state2):
        return abs(state1[0] - state2[0]) + abs(state1[1] - state2[1])
